import tensorflow_hub as hub
import tensorflow as tf
from nltk.tokenize import sent_tokenize
from sklearn.metrics.pairwise import cosine_similarity
import networkx as nx
from sklearn.metrics import pairwise_distances_argmin_min
import numpy as np
from sklearn.cluster import KMeans
import re

contractions = {
					"ain't": "am not / are not / is not / has not / have not",
					"aren't": "are not / am not",
					"can't": "cannot",
					"can't've": "cannot have",
					"'cause": "because",
					"could've": "could have",
					"couldn't": "could not",
					"couldn't've": "could not have",
					"didn't": "did not",
					"doesn't": "does not",
					"don't": "do not",
					"hadn't": "had not",
					"hadn't've": "had not have",
					"hasn't": "has not",
					"haven't": "have not",
					"he'd": "he had / he would",
					"he'd've": "he would have",
					"he'll": "he shall / he will",
					"he'll've": "he shall have / he will have",
					"he's": "he has / he is",
					"how'd": "how did",
					"how'd'y": "how do you",
					"how'll": "how will",
					"how's": "how has / how is / how does",
					"I'd": "I had / I would",
					"I'd've": "I would have",
					"I'll": "I shall / I will",
					"I'll've": "I shall have / I will have",
					"I'm": "I am",
					"I've": "I have",
					"isn't": "is not",
					"it'd": "it had / it would",
					"it'd've": "it would have",
					"it'll": "it shall / it will",
					"it'll've": "it shall have / it will have",
					"it's": "it has / it is",
					"let's": "let us",
					"ma'am": "madam",
					"mayn't": "may not",
					"might've": "might have",
					"mightn't": "might not",
					"mightn't've": "might not have",
					"must've": "must have",
					"mustn't": "must not",
					"mustn't've": "must not have",
					"needn't": "need not",
					"needn't've": "need not have",
					"o'clock": "of the clock",
					"oughtn't": "ought not",
					"oughtn't've": "ought not have",
					"shan't": "shall not",
					"sha'n't": "shall not",
					"shan't've": "shall not have",
					"she'd": "she had / she would",
					"she'd've": "she would have",
					"she'll": "she shall / she will",
					"she'll've": "she shall have / she will have",
					"she's": "she has / she is",
					"should've": "should have",
					"shouldn't": "should not",
					"shouldn't've": "should not have",
					"so've": "so have",
					"so's": "so as / so is",
					"that'd": "that would / that had",
					"that'd've": "that would have",
					"that's": "that has / that is",
					"there'd": "there had / there would",
					"there'd've": "there would have",
					"there's": "there has / there is",
					"they'd": "they had / they would",
					"they'd've": "they would have",
					"they'll": "they shall / they will",
					"they'll've": "they shall have / they will have",
					"they're": "they are",
					"they've": "they have",
					"to've": "to have",
					"wasn't": "was not",
					"we'd": "we had / we would",
					"we'd've": "we would have",
					"we'll": "we will",
					"we'll've": "we will have",
					"we're": "we are",
					"we've": "we have",
					"weren't": "were not",
					"what'll": "what shall / what will",
					"what'll've": "what shall have / what will have",
					"what're": "what are",
					"what's": "what has / what is",
					"what've": "what have",
					"when's": "when has / when is",
					"when've": "when have",
					"where'd": "where did",
					"where's": "where has / where is",
					"where've": "where have",
					"who'll": "who shall / who will",
					"who'll've": "who shall have / who will have",
					"who's": "who has / who is",
					"who've": "who have",
					"why's": "why has / why is",
					"why've": "why have",
					"will've": "will have",
					"won't": "will not",
					"won't've": "will not have",
					"would've": "would have",
					"wouldn't": "would not",
					"wouldn't've": "would not have",
					"y'all": "you all",
					"y'all'd": "you all would",
					"y'all'd've": "you all would have",
					"y'all're": "you all are",
					"y'all've": "you all have",
					"you'd": "you had / you would",
					"you'd've": "you would have",
					"you'll": "you shall / you will",
					"you'll've": "you shall have / you will have",
					"you're": "you are",
					"you've": "you have"
					}

def expand_contractions(s, contractions_dict=contractions):
	"""
	Input: Given input text
	Purpose: handle contractions
	Output: contraction handled text
	"""
	contractions_re = re.compile('(%s)' % '|'.join(contractions.keys()))
	def replace(match):
		return contractions_dict[match.group(0)]
	return contractions_re.sub(replace, s)


def USE_encoding(text):
	"""
	Input: Given input text
	Purpose: Universal Sentence Embeddings encodings for given text
	Output: text embeddings
	"""
	sentences = sent_tokenize(text)    
	sentences = [expand_contractions(i) for i in sentences]
	sentences = [re.sub('\n', '', i) for i in sentences]

	module_url = "https://tfhub.dev/google/universal-sentence-encoder/2"

	embed = hub.Module(module_url)

	# Reduce logging output.
	tf.logging.set_verbosity(tf.logging.ERROR)

	with tf.Session() as session:
	    session.run([tf.global_variables_initializer(), tf.tables_initializer()])
	    message_embeddings = session.run(embed(sentences))

	return message_embeddings,sentences    



def text_rank_using_USE(text,num_of_sentences):
	"""
	Input: Given input text, number of sentences in summary
	Purpose: Generate Summary, Text Rank using Universal Sentence Embeddings
	Output: summary of given text
	""" 
	message_embeddings,sentences=USE_encoding(text)
	#generate cosine similarity matrix
	sim_matrix = cosine_similarity(message_embeddings)

	#create graph and generate scores from pagerank algorithms
	nx_graph = nx.from_numpy_array(sim_matrix)
	scores = nx.pagerank(nx_graph)

	ranked_sentences = sorted(((scores[i],s) for i,s in enumerate(sentences)), reverse=True)   

	summary = " ".join([i[1] for i in ranked_sentences[:num_of_sentences]])
	return summary



def unsupervised_learning_USE(text):
	"""
	Input: Given input text
	Purpose: Generate Summary, K-means using Universal Sentence Embeddings
	Output: summary of given text
	""" 
	message_embeddings,sentences=USE_encoding(text)
	n_clusters = int(np.ceil(len(message_embeddings)**0.6))
	print(n_clusters)

	kmeans = KMeans(n_clusters=n_clusters)
	kmeans = kmeans.fit(message_embeddings)

	avg = []
	for j in range(n_clusters):
	    idx = np.where(kmeans.labels_ == j)[0]
	    avg.append(np.mean(idx))
	closest, _ = pairwise_distances_argmin_min(kmeans.cluster_centers_, message_embeddings)
	ordering = sorted(range(n_clusters), key=lambda k: avg[k])
	summary = ' '.join([sentences[closest[idx]] for idx in ordering])

	return summary