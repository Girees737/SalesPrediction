# Load Packages
from gensim.summarization.summarizer import summarize 
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.summarizers.luhn import LuhnSummarizer 
from sumy.summarizers.lex_rank import LexRankSummarizer
from sumy.summarizers.lsa import LsaSummarizer
from sumy.summarizers.text_rank import TextRankSummarizer
from sumy.summarizers.sum_basic import SumBasicSummarizer
from sumy.summarizers.kl import KLSummarizer
from sumy.summarizers.edmundson import EdmundsonSummarizer
from sumy.summarizers.reduction import ReductionSummarizer

def gensim_text_rank(text):
	"""
	Input: Given input text
	Purpose: Generate Summary
	Output: summary of given text
	"""
	try:
		return summarize(text)
	except:
		return ""

def luhn_summarizer(text,summary_size):

	"""
	Input: Given input text, number of sentences in summary
	Purpose: Generate Summary
	Output: summary of given text
	"""
	# For Strings
	parser = PlaintextParser.from_string(text,Tokenizer("english"))
	# Luhn Summarizer
	summarizer_luhn = LuhnSummarizer()
	summary_1 =summarizer_luhn(parser.document,summary_size)
	luhn_summary=""
	for sentence in summary_1:
		luhn_summary+=str(sentence)  
	return luhn_summary   
    
def lex_summarizer(text,summary_size):	
 	"""
	Input: Given input text, number of sentences in summary
	Purpose: Generate Summary
	Output: summary of given text
	"""
 	# For String
 	parser = PlaintextParser.from_string(text,Tokenizer("english"))
 	# LexRank Summarizer
 	summarizer_lex = LexRankSummarizer()
 	summary_2 = summarizer_lex(parser.document, summary_size)
 	lex_summary=""
 	for sentence in summary_2:
 		lex_summary+=str(sentence)  
 	return lex_summary    
    
def lsa_summarizer(text,summary_size):    
	"""
	Input: Given input text, number of sentences in summary
	Purpose: Generate Summary
	Output: summary of given text
	"""
	# For Strings
	parser = PlaintextParser.from_string(text,Tokenizer("english"))
	# LSA Summarizer
	summarizer_lsa = LsaSummarizer()
	summary_3 =summarizer_lsa(parser.document,summary_size)
	lsa_summary=""
	for sentence in summary_3:
		lsa_summary+=str(sentence)  
	return lsa_summary 

def text_rank_summarizer(text,summary_size):
	"""
	Input: Given input text, number of sentences in summary
	Purpose: Generate Summary
	Output: summary of given text
	"""
	# For Strings
	parser = PlaintextParser.from_string(text,Tokenizer("english"))
	# Text-Rank Summarizer
	summarizer_4 = TextRankSummarizer()
	summary_4 =summarizer_4(parser.document,summary_size)
	text_summary=""
	for sentence in summary_4:
		text_summary+=str(sentence)  
	return text_summary    

def sum_basic_summarizer(text,summary_size):
	"""
	Input: Given input text, number of sentences in summary
	Purpose: Generate Summary
	Output: summary of given text
	"""
	# For Strings
	parser = PlaintextParser.from_string(text,Tokenizer("english"))
	# Sum Basic Summarization
	summarizer_sum = SumBasicSummarizer()
	summary_5 =summarizer_sum(parser.document,summary_size)
	sum_summary=""
	for sentence in summary_5:
		sum_summary+=str(sentence) 
	return sum_summary     

def kl_summarizer(text,summary_size):
	"""
	Input: Given input text, number of sentences in summary
	Purpose: Generate Summary
	Output: summary of given text
	"""
	# For Strings
	parser = PlaintextParser.from_string(text,Tokenizer("english"))
	# KL Summarizer
	summarizer_kl = KLSummarizer()
	summary_6 =summarizer_kl(parser.document,summary_size)
	kl_summary=""
	for sentence in summary_6:
		kl_summary+=str(sentence)  
	return kl_summary    

def red_summarizer(text,summary_size):
	"""
	Input: Given input text, number of sentences in summary
	Purpose: Generate Summary
	Output: summary of given text
	"""
	# For Strings
	parser = PlaintextParser.from_string(text,Tokenizer("english"))
	# Reduction Summarizer
	summarizer_red = ReductionSummarizer()
	summary_7 =summarizer_red(parser.document,summary_size)
	red_summary=""
	for sentence in summary_7:
		red_summary+=str(sentence) 
	return red_summary

