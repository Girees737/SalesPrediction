from sentence_score import sentence_scoring_method

from summarizer import gensim_text_rank
from summarizer import luhn_summarizer
from summarizer import lex_summarizer
from summarizer import lsa_summarizer
from summarizer import text_rank_summarizer
from summarizer import sum_basic_summarizer
from summarizer import kl_summarizer
from summarizer import red_summarizer
from advanced_summarizer import text_rank_using_USE
from advanced_summarizer import unsupervised_learning_USE

text="""Why is Kashmir controversial?
Kashmir is a Himalayan region that both India and Pakistan say is fully theirs.

The area was once a princely state called Jammu and Kashmir, but it joined India in 1947 when the sub-continent was divided up at the end of British rule.

India and Pakistan subsequently went to war over it and each came to control different parts of the territory with a ceasefire line agreed.

There has been violence in the Indian-administered side - the state of Jammu and Kashmir - for 30 years due to a separatist insurgency against Indian rule.

What's happened now?
In the first few days of August, there were signs of something afoot in Kashmir.

Tens of thousands of additional Indian troops were deployed, a major Hindu pilgrimage was cancelled, schools and colleges were shut, tourists were ordered to leave, telephone and internet services were suspended and regional political leaders were placed under house arrest.

But most of the speculation was that Article 35A of the Indian constitution, which gave some special privileges to the people of the state, would be scrapped.

The government then stunned everyone by saying it was revoking nearly all of Article 370, which 35A is part of and which has been the basis of Kashmir's complex relationship with India for some 70 years.

How significant is Article 370?
The article allowed the state a certain amount of autonomy - its own constitution, a separate flag and freedom to make laws. Foreign affairs, defence and communications remained the preserve of the central government.

As a result, Jammu and Kashmir could make its own rules relating to permanent residency, ownership of property and fundamental rights. It could also bar Indians from outside the state from purchasing property or settling there.

Modi's Kashmir move will fuel resentment
Former chief minister says India has betrayed Kashmir
Why a special law on Kashmir is controversial
The constitutional provision has underpinned India's often fraught relationship with Kashmir, the only Muslim-majority region to join India at partition.

Why did the government do it?
Prime Minister Narendra Modi and the Hindu nationalist Bharatiya Janata Party had long opposed Article 370 and revoking it was in the party's 2019 election manifesto.

They argued it needed to be scrapped to integrate Kashmir and put it on the same footing as the rest of India. After returning to power with a massive mandate in the April-May general elections, the government lost no time in acting on its pledge.

Critics of Monday's move are linking it to the economic slowdown that India is currently facing - they say it provides a much-needed diversion for the government.
"""
# summary=sentence_scoring_method(text)
# print(summary)

# summary=gensim_text_rank(text)
# print(summary)

# summary=luhn_summarizer(text,3)
# print(summary)

# summary=lex_summarizer(text,3)
# print(summary)

# summary=lsa_summarizer(text,3)
# print(summary)

# summary=text_rank_summarizer(text,3)
# print(summary)

# summary=sum_basic_summarizer(text,3)
# print(summary)

# summary=kl_summarizer(text,3)
# print(summary)

# summary=red_summarizer(text,3)
# print(summary)

# summary=text_rank_using_USE(text,3)
# print(summary)

summary=unsupervised_learning_USE(text)
print(summary)

